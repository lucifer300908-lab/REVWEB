const mongoose = require('mongoose');

const contactSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Nama wajib diisi'],
    trim: true,
    maxlength: [100, 'Nama maksimal 100 karakter']
  },
  email: {
    type: String,
    required: [true, 'Email wajib diisi'],
    trim: true,
    lowercase: true,
    match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Format email tidak valid']
  },
  phone: {
    type: String,
    trim: true,
    maxlength: [20, 'Nomor telepon maksimal 20 karakter']
  },
  service: {
    type: String,
    enum: ['landing-page', 'ecommerce', 'web-app', 'uiux', 'seo', 'maintenance', 'other'],
    default: 'other'
  },
  budget: {
    type: String,
    enum: ['< 5jt', '5-15jt', '15-50jt', '> 50jt', 'diskusi'],
    default: 'diskusi'
  },
  message: {
    type: String,
    required: [true, 'Pesan wajib diisi'],
    trim: true,
    maxlength: [2000, 'Pesan maksimal 2000 karakter']
  },
  status: {
    type: String,
    enum: ['baru', 'diproses', 'selesai', 'ditolak'],
    default: 'baru'
  },
  adminNotes: {
    type: String,
    default: ''
  },
  ipAddress: String,
  userAgent: String,
  emailSent: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

// Index untuk query efisien
contactSchema.index({ status: 1, createdAt: -1 });
contactSchema.index({ email: 1 });

module.exports = mongoose.model('Contact', contactSchema);
