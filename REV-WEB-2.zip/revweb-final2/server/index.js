require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── SECURITY MIDDLEWARE ───────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? ['https://nexora.id', 'https://www.nexora.id']
    : '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Rate limiter global
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 menit
  max: 100,
  message: { success: false, message: 'Terlalu banyak request. Coba lagi 15 menit lagi.' }
});
app.use('/api/', globalLimiter);

// Rate limiter ketat untuk form kontak
const contactLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 jam
  max: 5,
  message: { success: false, message: 'Batas pengiriman form tercapai. Coba lagi 1 jam lagi.' }
});

// ─── BODY PARSER ──────────────────────────────────
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// ─── STATIC FILES ─────────────────────────────────
app.use(express.static(path.join(__dirname, '../public')));
app.use('/admin', express.static(path.join(__dirname, '../admin')));

// ─── DATABASE CONNECTION ───────────────────────────
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('✅ MongoDB terhubung:', process.env.MONGODB_URI))
  .catch(err => {
    console.error('❌ Gagal koneksi MongoDB:', err.message);
    process.exit(1);
  });

mongoose.connection.on('disconnected', () => console.warn('⚠️  MongoDB terputus'));
mongoose.connection.on('reconnected', () => console.log('🔄 MongoDB reconnected'));

// ─── ROUTES ───────────────────────────────────────
const contactRoutes = require('./routes/contact');
const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');

app.use('/api/contact', contactLimiter, contactRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);

// ─── HEALTH CHECK ─────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    status: 'Server berjalan normal',
    timestamp: new Date().toISOString(),
    dbStatus: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
  });
});

// ─── FRONTEND FALLBACK ─────────────────────────────
app.get('/admin/*', (req, res) => {
  res.sendFile(path.join(__dirname, '../admin/index.html'));
});
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// ─── ERROR HANDLER ────────────────────────────────
app.use((err, req, res, next) => {
  console.error('❌ Error:', err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: process.env.NODE_ENV === 'production'
      ? 'Terjadi kesalahan server'
      : err.message
  });
});

// ─── START SERVER ─────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 NEXORA Server berjalan di http://localhost:${PORT}`);
  console.log(`📊 Admin Dashboard: http://localhost:${PORT}/admin`);
  console.log(`🌍 Mode: ${process.env.NODE_ENV}\n`);
});

module.exports = app;
