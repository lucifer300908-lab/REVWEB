const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const nodemailer = require('nodemailer');
const Contact = require('../models/Contact');

// ─── EMAIL TRANSPORTER ─────────────────────────────
const createTransporter = () => nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: parseInt(process.env.EMAIL_PORT),
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// ─── EMAIL TEMPLATES ───────────────────────────────
const adminEmailTemplate = (data) => `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>
  body { font-family: 'Segoe UI', sans-serif; background: #0a0a0a; color: #f5f0e8; margin: 0; padding: 0; }
  .wrapper { max-width: 600px; margin: 0 auto; background: #111; border: 1px solid #222; border-radius: 16px; overflow: hidden; }
  .header { background: #c8ff00; padding: 32px; text-align: center; }
  .header h1 { color: #000; font-size: 24px; margin: 0; font-weight: 800; letter-spacing: -0.5px; }
  .body { padding: 36px; }
  .badge { display: inline-block; background: rgba(200,255,0,0.15); color: #c8ff00; border: 1px solid rgba(200,255,0,0.3); padding: 6px 14px; border-radius: 100px; font-size: 12px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 24px; }
  .field { margin-bottom: 20px; }
  .label { font-size: 11px; color: rgba(245,240,232,0.4); text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 6px; }
  .value { font-size: 15px; color: #f5f0e8; background: #1a1a1a; padding: 14px 18px; border-radius: 10px; border: 1px solid #2a2a2a; }
  .message-box { background: #1a1a1a; border: 1px solid #2a2a2a; border-radius: 10px; padding: 20px; margin-top: 8px; font-size: 15px; line-height: 1.6; white-space: pre-wrap; }
  .footer { padding: 24px 36px; border-top: 1px solid #1a1a1a; text-align: center; font-size: 12px; color: rgba(245,240,232,0.25); }
  .cta { display: block; background: #c8ff00; color: #000; padding: 14px 28px; border-radius: 10px; text-decoration: none; font-weight: 700; font-size: 14px; margin: 28px 0; text-align: center; }
</style></head>
<body>
<div class="wrapper">
  <div class="header"><h1>⚡ NEXORA — Pesan Baru!</h1></div>
  <div class="body">
    <span class="badge">✦ Kontak Masuk</span>
    <div class="field"><div class="label">Nama</div><div class="value">${data.name}</div></div>
    <div class="field"><div class="label">Email</div><div class="value">${data.email}</div></div>
    <div class="field"><div class="label">Telepon</div><div class="value">${data.phone || '—'}</div></div>
    <div class="field"><div class="label">Layanan yang Diminati</div><div class="value">${data.service}</div></div>
    <div class="field"><div class="label">Budget</div><div class="value">${data.budget}</div></div>
    <div class="field"><div class="label">Pesan</div><div class="message-box">${data.message}</div></div>
    <a href="mailto:${data.email}" class="cta">Balas Email Sekarang →</a>
  </div>
  <div class="footer">NEXORA Studio • Diterima ${new Date().toLocaleString('id-ID')}</div>
</div>
</body></html>
`;

const clientEmailTemplate = (name) => `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>
  body { font-family: 'Segoe UI', sans-serif; background: #0a0a0a; color: #f5f0e8; margin: 0; padding: 0; }
  .wrapper { max-width: 600px; margin: 0 auto; background: #111; border: 1px solid #222; border-radius: 16px; overflow: hidden; }
  .header { background: #c8ff00; padding: 40px 32px; text-align: center; }
  .header h1 { color: #000; font-size: 28px; margin: 0 0 8px; font-weight: 800; }
  .header p { color: rgba(0,0,0,0.6); font-size: 14px; margin: 0; }
  .body { padding: 40px 36px; }
  .greeting { font-size: 22px; font-weight: 700; margin-bottom: 16px; }
  .text { font-size: 15px; line-height: 1.7; color: rgba(245,240,232,0.65); margin-bottom: 16px; }
  .highlight { background: rgba(200,255,0,0.08); border-left: 3px solid #c8ff00; padding: 20px 24px; border-radius: 0 10px 10px 0; margin: 28px 0; }
  .highlight p { margin: 6px 0; font-size: 14px; color: rgba(245,240,232,0.7); }
  .highlight strong { color: #c8ff00; }
  .footer { padding: 24px 36px; border-top: 1px solid #1a1a1a; text-align: center; font-size: 12px; color: rgba(245,240,232,0.25); }
</style></head>
<body>
<div class="wrapper">
  <div class="header">
    <h1>NEXORA</h1>
    <p>Studio Web Premium • Jakarta</p>
  </div>
  <div class="body">
    <div class="greeting">Hei, ${name}! 👋</div>
    <p class="text">Terima kasih sudah menghubungi <strong>NEXORA Studio</strong>. Kami sudah menerima pesan kamu dan akan segera menghubungi kamu dalam waktu <strong style="color:#c8ff00">1×24 jam kerja</strong>.</p>
    <p class="text">Sementara menunggu, berikut yang perlu kamu tahu:</p>
    <div class="highlight">
      <p>⏱️ <strong>Response time:</strong> Maksimal 24 jam kerja</p>
      <p>📞 <strong>WhatsApp:</strong> +62 812-3456-7890</p>
      <p>📧 <strong>Email:</strong> hello@nexora.id</p>
      <p>🕐 <strong>Jam kerja:</strong> Senin–Jumat, 09.00–18.00 WIB</p>
    </div>
    <p class="text">Kalau ada pertanyaan mendesak, langsung hubungi kami via WhatsApp ya!</p>
    <p class="text">Salam hangat,<br/><strong>Tim NEXORA Studio</strong></p>
  </div>
  <div class="footer">© 2024 NEXORA Studio • Jakarta, Indonesia</div>
</div>
</body></html>
`;

// ─── POST /api/contact ─────────────────────────────
router.post('/',
  [
    body('name').trim().notEmpty().withMessage('Nama wajib diisi').isLength({ max: 100 }),
    body('email').isEmail().withMessage('Format email tidak valid').normalizeEmail(),
    body('message').trim().notEmpty().withMessage('Pesan wajib diisi').isLength({ max: 2000 }),
    body('phone').optional().trim().isLength({ max: 20 }),
    body('service').optional().isIn(['landing-page', 'ecommerce', 'web-app', 'uiux', 'seo', 'maintenance', 'other']),
    body('budget').optional().isIn(['< 5jt', '5-15jt', '15-50jt', '> 50jt', 'diskusi'])
  ],
  async (req, res) => {
    // Validasi input
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: errors.array()[0].msg,
        errors: errors.array()
      });
    }

    try {
      const { name, email, phone, service, budget, message } = req.body;

      // Simpan ke database
      const contact = await Contact.create({
        name, email, phone, service, budget, message,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent']
      });

      // Kirim email (tidak blocking — pakai Promise.allSettled)
      let emailSent = false;
      try {
        const transporter = createTransporter();
        await Promise.allSettled([
          // Email ke admin
          transporter.sendMail({
            from: process.env.EMAIL_FROM,
            to: process.env.ADMIN_EMAIL,
            subject: `[NEXORA] Pesan Baru dari ${name}`,
            html: adminEmailTemplate({ name, email, phone, service, budget, message })
          }),
          // Email konfirmasi ke klien
          transporter.sendMail({
            from: process.env.EMAIL_FROM,
            to: email,
            subject: 'Pesan kamu sudah kami terima — NEXORA Studio',
            html: clientEmailTemplate(name)
          })
        ]);
        emailSent = true;
        await Contact.findByIdAndUpdate(contact._id, { emailSent: true });
      } catch (emailErr) {
        console.error('⚠️  Email gagal terkirim:', emailErr.message);
        // Tidak gagalkan response — data tetap tersimpan
      }

      res.status(201).json({
        success: true,
        message: 'Pesan berhasil dikirim! Kami akan menghubungi kamu segera.',
        data: {
          id: contact._id,
          name: contact.name,
          email: contact.email,
          emailSent
        }
      });
    } catch (err) {
      console.error('❌ Error kontak:', err);
      res.status(500).json({
        success: false,
        message: 'Gagal menyimpan pesan. Coba lagi beberapa saat.'
      });
    }
  }
);

// ─── GET /api/contact (simple check) ──────────────
router.get('/check', (req, res) => {
  res.json({ success: true, message: 'Contact API aktif' });
});

module.exports = router;
