const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const Contact = require('../models/Contact');

// Semua route admin butuh auth
router.use(protect);

// ─── GET /api/admin/contacts ───────────────────────
router.get('/contacts', async (req, res) => {
  try {
    const { status, page = 1, limit = 20, search } = req.query;
    const query = {};

    if (status && status !== 'semua') query.status = status;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const [contacts, total] = await Promise.all([
      Contact.find(query).sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)),
      Contact.countDocuments(query)
    ]);

    res.json({
      success: true,
      data: contacts,
      pagination: {
        total,
        page: parseInt(page),
        totalPages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Gagal mengambil data.' });
  }
});

// ─── GET /api/admin/contacts/stats ────────────────
router.get('/contacts/stats', async (req, res) => {
  try {
    const [total, baru, diproses, selesai, ditolak, thisMonth] = await Promise.all([
      Contact.countDocuments(),
      Contact.countDocuments({ status: 'baru' }),
      Contact.countDocuments({ status: 'diproses' }),
      Contact.countDocuments({ status: 'selesai' }),
      Contact.countDocuments({ status: 'ditolak' }),
      Contact.countDocuments({
        createdAt: { $gte: new Date(new Date().setDate(1)) }
      })
    ]);

    // Data chart 6 bulan terakhir
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 5);
    sixMonthsAgo.setDate(1);

    const monthlyData = await Contact.aggregate([
      { $match: { createdAt: { $gte: sixMonthsAgo } } },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' }
          },
          count: { $sum: 1 }
        }
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } }
    ]);

    res.json({
      success: true,
      stats: { total, baru, diproses, selesai, ditolak, thisMonth },
      monthlyData
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Gagal mengambil statistik.' });
  }
});

// ─── PATCH /api/admin/contacts/:id ────────────────
router.patch('/contacts/:id', async (req, res) => {
  try {
    const { status, adminNotes } = req.body;
    const update = {};
    if (status) update.status = status;
    if (adminNotes !== undefined) update.adminNotes = adminNotes;

    const contact = await Contact.findByIdAndUpdate(
      req.params.id, update, { new: true, runValidators: true }
    );

    if (!contact) {
      return res.status(404).json({ success: false, message: 'Data tidak ditemukan.' });
    }

    res.json({ success: true, message: 'Data berhasil diupdate.', data: contact });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Gagal update data.' });
  }
});

// ─── DELETE /api/admin/contacts/:id ───────────────
router.delete('/contacts/:id', async (req, res) => {
  try {
    const contact = await Contact.findByIdAndDelete(req.params.id);
    if (!contact) {
      return res.status(404).json({ success: false, message: 'Data tidak ditemukan.' });
    }
    res.json({ success: true, message: 'Data berhasil dihapus.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Gagal menghapus data.' });
  }
});

module.exports = router;
