const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const Admin = require('../models/Admin');
const { protect } = require('../middleware/auth');
const rateLimit = require('express-rate-limit');

// Rate limiter ketat untuk login
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { success: false, message: 'Terlalu banyak percobaan login. Tunggu 15 menit.' }
});

const signToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET, {
  expiresIn: process.env.JWT_EXPIRES_IN || '7d'
});

// ─── POST /api/auth/login ──────────────────────────
router.post('/login', loginLimiter,
  [
    body('username').trim().notEmpty().withMessage('Username wajib diisi'),
    body('password').notEmpty().withMessage('Password wajib diisi')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, message: errors.array()[0].msg });
    }

    try {
      const { username, password } = req.body;

      const admin = await Admin.findOne({ username: username.toLowerCase() }).select('+password');
      if (!admin || !admin.isActive) {
        return res.status(401).json({ success: false, message: 'Username atau password salah.' });
      }

      const isMatch = await admin.comparePassword(password);
      if (!isMatch) {
        return res.status(401).json({ success: false, message: 'Username atau password salah.' });
      }

      // Update lastLogin
      admin.lastLogin = new Date();
      await admin.save({ validateBeforeSave: false });

      const token = signToken(admin._id);

      res.json({
        success: true,
        message: 'Login berhasil',
        token,
        admin: {
          id: admin._id,
          username: admin.username,
          name: admin.name,
          role: admin.role,
          lastLogin: admin.lastLogin
        }
      });
    } catch (err) {
      console.error('Login error:', err);
      res.status(500).json({ success: false, message: 'Terjadi kesalahan server.' });
    }
  }
);

// ─── GET /api/auth/me ──────────────────────────────
router.get('/me', protect, (req, res) => {
  res.json({
    success: true,
    admin: {
      id: req.admin._id,
      username: req.admin.username,
      name: req.admin.name,
      role: req.admin.role,
      lastLogin: req.admin.lastLogin
    }
  });
});

// ─── POST /api/auth/change-password ───────────────
router.post('/change-password', protect,
  [
    body('currentPassword').notEmpty().withMessage('Password lama wajib diisi'),
    body('newPassword').isLength({ min: 8 }).withMessage('Password baru minimal 8 karakter')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, message: errors.array()[0].msg });
    }

    try {
      const admin = await Admin.findById(req.admin._id).select('+password');
      const isMatch = await admin.comparePassword(req.body.currentPassword);
      if (!isMatch) {
        return res.status(400).json({ success: false, message: 'Password lama tidak sesuai.' });
      }

      admin.password = req.body.newPassword;
      await admin.save();

      res.json({ success: true, message: 'Password berhasil diubah.' });
    } catch (err) {
      res.status(500).json({ success: false, message: 'Gagal mengubah password.' });
    }
  }
);

module.exports = router;
