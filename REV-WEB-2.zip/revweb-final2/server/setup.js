require("dotenv").config();
const mongoose = require("mongoose");
const Admin = require("./models/Admin");

async function setup() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("MongoDB terhubung");
    const existing = await Admin.findOne({ username: process.env.ADMIN_USERNAME });
    if (existing) { console.log("Admin sudah ada:", existing.username); process.exit(0); }
    const admin = await Admin.create({
      username: process.env.ADMIN_USERNAME || "admin",
      password: process.env.ADMIN_PASSWORD || "Admin123!",
      name: "Admin REV-WEB",
      role: "superadmin"
    });
    console.log("Admin berhasil dibuat! Username:", admin.username);
  } catch (err) {
    console.error("Setup gagal:", err.message);
  } finally {
    await mongoose.disconnect();
    process.exit(0);
  }
}
setup();
